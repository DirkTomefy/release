package mg.bovit.release.controller;

import mg.bovit.release.model.Contrat;
import mg.bovit.release.model.Employee;
import mg.bovit.release.repository.EmployeeRepository;
import mg.bovit.release.service.ContratService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class ContratController {

    @Autowired
    private ContratService contratService;

    @Autowired
    private EmployeeRepository employeeRepository;

    @GetMapping({"/contrat", "/contrat/list"})
    public String listContrats(Model model) {
        model.addAttribute("contrats", contratService.findAllContrats());
        model.addAttribute("employees", employeeRepository.findAll());
        model.addAttribute("contrat", new Contrat());
        return "contrat/form";
    }

    @GetMapping("/contrat/new")
    public String showContratForm(Model model) {
        List<Employee> employees = employeeRepository.findAll();

        model.addAttribute("contrat", new Contrat());
        model.addAttribute("employees", employees);
        model.addAttribute("contrats", contratService.findAllContrats());

        return "contrat/form";
    }

    @PostMapping("/contrat/save")
    public String saveContrat(@ModelAttribute("contrat") Contrat contrat,
                              @RequestParam("employeeId") Long employeeId,
                              Model model) {
        try {
            contratService.saveContratWithEmployee(contrat, employeeId);
            return "redirect:/contrat/list";
        } catch (Exception ex) {
            List<Employee> employees = employeeRepository.findAll();
            model.addAttribute("contrat", contrat);
            model.addAttribute("employees", employees);
            model.addAttribute("contrats", contratService.findAllContrats());
            model.addAttribute("selectedEmployeeId", employeeId);
            model.addAttribute("errorMessage", ex.getMessage() != null ? ex.getMessage() : "Une erreur est survenue lors de l'enregistrement du contrat.");
            return "contrat/form";
        }
    }
}